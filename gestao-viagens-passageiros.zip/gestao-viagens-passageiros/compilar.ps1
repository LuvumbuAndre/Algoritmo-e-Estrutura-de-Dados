﻿New-Item -ItemType Directory -Force -Path out | Out-Null
$files = Get-ChildItem -Path src -Recurse -Filter *.java | ForEach-Object { $_.FullName }
Write-Host "A compilar $($files.Count) ficheiros..."
javac -encoding UTF-8 -d out @files
if ($LASTEXITCODE -eq 0) {
    Write-Host "Compilação OK. Executar: java -cp out Main"
} else {
    Write-Host "Falha na compilação."
    exit 1
}
