# Sistema de Gestão de Viagens e Passageiros

Projecto académico (AED I) — demonstração prática de **Tabelas de Espalhamento** com resolução de colisões por **encadeamento (Separate Chaining)**.

- Linguagem: Java 21 (sem bibliotecas externas)
- Interface: consola com menus em português
- Estrutura própria: `estrutura.TabelaHash` (não usa `java.util.HashMap` como armazenamento)

## Estrutura do projecto

```
src/
  Main.java                 # Ponto de entrada
  DadosIniciais.java        # Dados de exemplo (Angola)
  estrutura/
    No.java                 # Nó da lista encadeada
    TabelaHash.java         # Hash table + encadeamento
  modelo/                   # Passageiro, Transporte, Viagem, Reserva, Bilhete
  servico/                  # Regras de negócio + fachada SistemaGestao
  ui/                       # Menus de consola
  demo/
    DemoColisoes.java       # Demo curta para o seminário (~3 min)
```

## Como compilar e executar

Na pasta do projecto (`gestao-viagens-passageiros`):

```bat
javac -encoding UTF-8 -d out (Get-ChildItem -Recurse -Filter *.java | ForEach-Object { $_.FullName })
```

PowerShell (recomendado):

```powershell
New-Item -ItemType Directory -Force -Path out | Out-Null
$files = Get-ChildItem -Path src -Recurse -Filter *.java | ForEach-Object { $_.FullName }
javac -encoding UTF-8 -d out $files
java -cp out Main
```

### Opções

| Comando | Efeito |
|---------|--------|
| `java -cp out Main` | Menu interactivo com dados de exemplo |
| `java -cp out Main --demo` | Só a demonstração de colisões |
| `java -cp out Main --sem-dados` | Menu sem dados iniciais |

## Fluxo principal

1. Registar **transporte** → 2. Registar **viagem** → 3. Registar **passageiro** → 4. Criar **reserva** → 5. Emitir **bilhete**

Pesquisa e remoção usam a tabela hash (`inserir` / `pesquisar` / `remover`).

## Seminário — o que destacar

1. Função hash (método da divisão + hash polinomial para `String`)
2. Colisões resolvidas por listas encadeadas nos baldes
3. Factor de carga `α = n/m` e rehash quando `α ≥ 0.75`
4. Menu **6** ou `java -cp out Main --demo` para mostrar colisões no ecrã
5. Em qualquer módulo: opção **Ver tabela hash**

## Primeira alteração sugerida

Melhorar `DemoColisoes` ou o `toString()` de `TabelaHash` para o esquema gráfico dos slides (baldes + listas).
