package demo;

import estrutura.TabelaHash;

/**
 * Demonstração académica de colisões por encadeamento.
 * Ideal para os ~3 minutos de demonstração do seminário.
 *
 * Usa capacidade pequena (m=7) e chaves escolhidas para colidir,
 * mantendo n baixo para não disparar rehash durante a demo.
 */
public final class DemoColisoes {

    private DemoColisoes() {
    }

    public static void executar() {
        System.out.println();
        System.out.println("================================================");
        System.out.println("  DEMONSTRACAO: COLISOES NA TABELA HASH");
        System.out.println("  Resolucao: Encadeamento (Separate Chaining)");
        System.out.println("================================================");
        System.out.println();

        // m=7 (primo). Com n<=5, alpha < 0.75 e nao ha rehash no meio da demo.
        TabelaHash<String, String> tabela = new TabelaHash<>(7);

        // Chaves seleccionadas: PAS001 e PAS008 → indice 1; PAS004 e LOBITO → indice 4
        String[][] dados = {
                {"PAS001", "Maria Fernanda"},
                {"PAS008", "Carlos Domingos"},   // colide com PAS001 (balde 1)
                {"PAS004", "Joao Pedro"},
                {"LOBITO", "Rota costeira"},     // colide com PAS004 (balde 4)
                {"BENGUELA", "Rota sul"}         // tambem colide no balde 4
        };

        System.out.println("1) Insercao sucessiva (h(k) = hashString(k) mod 7):");
        System.out.println();

        for (String[] par : dados) {
            String chave = par[0];
            String valor = par[1];
            int indice = tabela.hash(chave);
            int antes = tabela.tamanhoBalde(indice);
            tabela.inserir(chave, valor);
            int depois = tabela.tamanhoBalde(indice);

            System.out.printf("   inserir(%s) -> indice %d", chave, indice);
            if (depois > 1) {
                System.out.printf("  << COLISAO (lista com %d nos)", depois);
                if (antes >= 1) {
                    System.out.print(" | encadeamento");
                }
            }
            System.out.println();
        }

        System.out.println();
        System.out.println("2) Estado da tabela (baldes + listas de colisao):");
        System.out.println(tabela);

        System.out.println("3) Pesquisa O(1+alpha) media:");
        System.out.printf("   pesquisar(PAS001)  = %s  [hash=%d]%n",
                tabela.pesquisar("PAS001"), tabela.hash("PAS001"));
        System.out.printf("   pesquisar(LOBITO)  = %s  [hash=%d]%n",
                tabela.pesquisar("LOBITO"), tabela.hash("LOBITO"));
        System.out.printf("   pesquisar(INEXIST)= %s%n", tabela.pesquisar("INEXIST"));

        System.out.println();
        System.out.println("4) Remocao de PAS001 (desliga o no da lista do balde 1):");
        tabela.remover("PAS001");
        System.out.println(tabela);

        System.out.println("5) Analise:");
        System.out.printf("   n (elementos)      = %d%n", tabela.tamanho());
        System.out.printf("   m (capacidade)     = %d%n", tabela.getCapacidade());
        System.out.printf("   alpha (n/m)        = %.3f%n", tabela.factorCarga());
        System.out.printf("   baldes com colisao = %d%n", tabela.contarBaldesComColisao());
        System.out.println();
        System.out.println("   Custo esperado (encadeamento, hipoteses simples): O(1 + alpha)");
        System.out.println("   As listas nos baldes 1 e 4 mostram as colisoes explicitamente.");
    }
}
