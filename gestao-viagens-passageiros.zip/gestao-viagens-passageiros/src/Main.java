import demo.DemoColisoes;
import servico.SistemaGestao;
import ui.MenuPrincipal;

/**
 * Classe principal do Sistema de Gestão de Viagens e Passageiros.
 *
 * Uso:
 *   java Main              → menu interactivo (com dados de exemplo)
 *   java Main --demo       → só a demonstração de colisões (seminário)
 *   java Main --sem-dados  → menu sem dados iniciais
 */
public class Main {

    public static void main(String[] args) {
        if (args.length > 0 && args[0].equalsIgnoreCase("--demo")) {
            DemoColisoes.executar();
            return;
        }

        SistemaGestao sistema = new SistemaGestao();

        boolean carregarDados = true;
        for (String arg : args) {
            if (arg.equalsIgnoreCase("--sem-dados")) {
                carregarDados = false;
            }
        }

        if (carregarDados) {
            DadosIniciais.carregar(sistema);
            System.out.println("Dados de exemplo carregados (Luanda / Benguela / Lubango / Sumbe).");
        }

        new MenuPrincipal(sistema).iniciar();
    }
}
