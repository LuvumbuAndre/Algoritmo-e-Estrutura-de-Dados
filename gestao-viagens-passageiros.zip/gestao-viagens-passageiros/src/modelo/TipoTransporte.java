package modelo;

public enum TipoTransporte {
    AUTOCARRO("Autocarro"),
    MINIBUS("Minibus"),
    AVIAO("Avião"),
    COMBOIO("Comboio"),
    BARCO("Barco");

    private final String rotulo;

    TipoTransporte(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }

    public static TipoTransporte deCodigo(String codigo) {
        if (codigo == null) {
            return null;
        }
        try {
            int n = Integer.parseInt(codigo.trim());
            TipoTransporte[] valores = values();
            if (n >= 1 && n <= valores.length) {
                return valores[n - 1];
            }
        } catch (NumberFormatException ignored) {
            // tenta pelo nome
        }
        try {
            return valueOf(codigo.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }

    @Override
    public String toString() {
        return rotulo;
    }
}
