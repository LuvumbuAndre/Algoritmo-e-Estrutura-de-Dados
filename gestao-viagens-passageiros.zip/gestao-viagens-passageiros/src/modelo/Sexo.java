package modelo;

public enum Sexo {
    MASCULINO("Masculino"),
    FEMININO("Feminino");

    private final String rotulo;

    Sexo(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }

    public static Sexo deCodigo(String codigo) {
        if (codigo == null) {
            return null;
        }
        String c = codigo.trim().toUpperCase();
        if (c.equals("M") || c.equals("MASCULINO") || c.equals("1")) {
            return MASCULINO;
        }
        if (c.equals("F") || c.equals("FEMININO") || c.equals("2")) {
            return FEMININO;
        }
        return null;
    }

    @Override
    public String toString() {
        return rotulo;
    }
}
