package modelo;

/**
 * Entidade Viagem — chave: código (ex.: VIG001).
 */
public class Viagem {
    private String codigo;
    private String origem;
    private String destino;
    private String dataHoraPartida; // AAAA-MM-DD HH:MM
    private double preco;
    private int lugaresDisponiveis;
    private String codigoTransporte;

    public Viagem(String codigo, String origem, String destino, String dataHoraPartida,
                  double preco, int lugaresDisponiveis, String codigoTransporte) {
        this.codigo = codigo;
        this.origem = origem;
        this.destino = destino;
        this.dataHoraPartida = dataHoraPartida;
        this.preco = preco;
        this.lugaresDisponiveis = lugaresDisponiveis;
        this.codigoTransporte = codigoTransporte;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getOrigem() {
        return origem;
    }

    public void setOrigem(String origem) {
        this.origem = origem;
    }

    public String getDestino() {
        return destino;
    }

    public void setDestino(String destino) {
        this.destino = destino;
    }

    public String getDataHoraPartida() {
        return dataHoraPartida;
    }

    public void setDataHoraPartida(String dataHoraPartida) {
        this.dataHoraPartida = dataHoraPartida;
    }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public int getLugaresDisponiveis() {
        return lugaresDisponiveis;
    }

    public void setLugaresDisponiveis(int lugaresDisponiveis) {
        this.lugaresDisponiveis = lugaresDisponiveis;
    }

    public String getCodigoTransporte() {
        return codigoTransporte;
    }

    public void setCodigoTransporte(String codigoTransporte) {
        this.codigoTransporte = codigoTransporte;
    }

    public boolean reservarLugar() {
        if (lugaresDisponiveis <= 0) {
            return false;
        }
        lugaresDisponiveis--;
        return true;
    }

    public void libertarLugar() {
        lugaresDisponiveis++;
    }

    @Override
    public String toString() {
        return String.format(
                "Viagem{codigo='%s', %s → %s, partida='%s', preço=%.2f Kz, lugares=%d, transporte='%s'}",
                codigo, origem, destino, dataHoraPartida, preco, lugaresDisponiveis, codigoTransporte);
    }
}
