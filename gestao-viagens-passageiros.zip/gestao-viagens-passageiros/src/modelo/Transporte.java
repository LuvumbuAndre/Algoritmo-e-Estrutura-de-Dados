package modelo;

/**
 * Entidade Transporte — chave: código (ex.: TRP001).
 */
public class Transporte {
    private String codigo;
    private TipoTransporte tipo;
    private String identificacao; // matrícula, prefixo aéreo, etc.
    private String empresa;
    private int capacidade;

    public Transporte(String codigo, TipoTransporte tipo, String identificacao,
                      String empresa, int capacidade) {
        this.codigo = codigo;
        this.tipo = tipo;
        this.identificacao = identificacao;
        this.empresa = empresa;
        this.capacidade = capacidade;
    }

    public String getCodigo() {
        return codigo;
    }

    public TipoTransporte getTipo() {
        return tipo;
    }

    public void setTipo(TipoTransporte tipo) {
        this.tipo = tipo;
    }

    public String getIdentificacao() {
        return identificacao;
    }

    public void setIdentificacao(String identificacao) {
        this.identificacao = identificacao;
    }

    public String getEmpresa() {
        return empresa;
    }

    public void setEmpresa(String empresa) {
        this.empresa = empresa;
    }

    public int getCapacidade() {
        return capacidade;
    }

    public void setCapacidade(int capacidade) {
        this.capacidade = capacidade;
    }

    @Override
    public String toString() {
        return String.format(
                "Transporte{codigo='%s', tipo=%s, id='%s', empresa='%s', capacidade=%d}",
                codigo, tipo, identificacao, empresa, capacidade);
    }
}
