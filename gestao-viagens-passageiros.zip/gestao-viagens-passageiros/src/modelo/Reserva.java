package modelo;

/**
 * Entidade Reserva — chave: código (ex.: RES001).
 */
public class Reserva {
    private String codigo;
    private String codigoPassageiro;
    private String codigoViagem;
    private String dataReserva; // AAAA-MM-DD
    private EstadoReserva estado;
    private int quantidadeLugares;

    public Reserva(String codigo, String codigoPassageiro, String codigoViagem,
                   String dataReserva, EstadoReserva estado, int quantidadeLugares) {
        this.codigo = codigo;
        this.codigoPassageiro = codigoPassageiro;
        this.codigoViagem = codigoViagem;
        this.dataReserva = dataReserva;
        this.estado = estado;
        this.quantidadeLugares = quantidadeLugares;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getCodigoPassageiro() {
        return codigoPassageiro;
    }

    public String getCodigoViagem() {
        return codigoViagem;
    }

    public String getDataReserva() {
        return dataReserva;
    }

    public EstadoReserva getEstado() {
        return estado;
    }

    public void setEstado(EstadoReserva estado) {
        this.estado = estado;
    }

    public int getQuantidadeLugares() {
        return quantidadeLugares;
    }

    @Override
    public String toString() {
        return String.format(
                "Reserva{codigo='%s', passageiro='%s', viagem='%s', data='%s', estado=%s, lugares=%d}",
                codigo, codigoPassageiro, codigoViagem, dataReserva, estado, quantidadeLugares);
    }
}
