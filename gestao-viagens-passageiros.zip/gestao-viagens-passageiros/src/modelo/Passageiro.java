package modelo;

/**
 * Entidade Passageiro — chave de pesquisa: código único (ex.: PAS001).
 */
public class Passageiro {
    private String codigo;
    private String nomeCompleto;
    private String numeroBI;
    private String dataNascimento; // formato AAAA-MM-DD
    private Sexo sexo;
    private String telefone;
    private String email;

    public Passageiro(String codigo, String nomeCompleto, String numeroBI,
                      String dataNascimento, Sexo sexo, String telefone, String email) {
        this.codigo = codigo;
        this.nomeCompleto = nomeCompleto;
        this.numeroBI = numeroBI;
        this.dataNascimento = dataNascimento;
        this.sexo = sexo;
        this.telefone = telefone;
        this.email = email;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNomeCompleto() {
        return nomeCompleto;
    }

    public void setNomeCompleto(String nomeCompleto) {
        this.nomeCompleto = nomeCompleto;
    }

    public String getNumeroBI() {
        return numeroBI;
    }

    public void setNumeroBI(String numeroBI) {
        this.numeroBI = numeroBI;
    }

    public String getDataNascimento() {
        return dataNascimento;
    }

    public void setDataNascimento(String dataNascimento) {
        this.dataNascimento = dataNascimento;
    }

    public Sexo getSexo() {
        return sexo;
    }

    public void setSexo(Sexo sexo) {
        this.sexo = sexo;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    @Override
    public String toString() {
        return String.format(
                "Passageiro{codigo='%s', nome='%s', BI='%s', nasc='%s', sexo=%s, tel='%s', email='%s'}",
                codigo, nomeCompleto, numeroBI, dataNascimento, sexo, telefone, email);
    }
}
