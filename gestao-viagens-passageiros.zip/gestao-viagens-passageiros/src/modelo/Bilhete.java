package modelo;

/**
 * Entidade Bilhete — chave: número (ex.: BIL001).
 */
public class Bilhete {
    private String numero;
    private String codigoReserva;
    private String dataEmissao;
    private String assento;
    private EstadoBilhete estado;
    private double valorPago;

    public Bilhete(String numero, String codigoReserva, String dataEmissao,
                   String assento, EstadoBilhete estado, double valorPago) {
        this.numero = numero;
        this.codigoReserva = codigoReserva;
        this.dataEmissao = dataEmissao;
        this.assento = assento;
        this.estado = estado;
        this.valorPago = valorPago;
    }

    public String getNumero() {
        return numero;
    }

    public String getCodigoReserva() {
        return codigoReserva;
    }

    public String getDataEmissao() {
        return dataEmissao;
    }

    public String getAssento() {
        return assento;
    }

    public void setAssento(String assento) {
        this.assento = assento;
    }

    public EstadoBilhete getEstado() {
        return estado;
    }

    public void setEstado(EstadoBilhete estado) {
        this.estado = estado;
    }

    public double getValorPago() {
        return valorPago;
    }

    @Override
    public String toString() {
        return String.format(
                "Bilhete{numero='%s', reserva='%s', emissão='%s', assento='%s', estado=%s, valor=%.2f Kz}",
                numero, codigoReserva, dataEmissao, assento, estado, valorPago);
    }
}
