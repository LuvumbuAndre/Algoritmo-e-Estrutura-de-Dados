package modelo;

public enum EstadoBilhete {
    EMITIDO("Emitido"),
    USADO("Usado"),
    CANCELADO("Cancelado");

    private final String rotulo;

    EstadoBilhete(String rotulo) {
        this.rotulo = rotulo;
    }

    public String getRotulo() {
        return rotulo;
    }

    @Override
    public String toString() {
        return rotulo;
    }
}
