import modelo.Sexo;
import modelo.TipoTransporte;
import servico.SistemaGestao;

/**
 * Carrega um conjunto pequeno de dados angolanos para demonstração.
 */
public final class DadosIniciais {

    private DadosIniciais() {
    }

    public static void carregar(SistemaGestao sistema) {
        // Passageiros
        sistema.getPassageiros().registar(
                "Maria Fernanda dos Santos", "004567890LA045",
                "1998-03-12", Sexo.FEMININO, "923000111", "maria@email.ao");
        sistema.getPassageiros().registar(
                "João Pedro Manuel", "003456789LA033",
                "1995-07-21", Sexo.MASCULINO, "924111222", "joao@email.ao");
        sistema.getPassageiros().registar(
                "Ana Luísa Costa", "002345678LA021",
                "2000-11-05", Sexo.FEMININO, "925222333", "ana@email.ao");

        // Transportes
        sistema.getTransportes().registar(
                TipoTransporte.AUTOCARRO, "LD-42-01", "Macon", 45);
        sistema.getTransportes().registar(
                TipoTransporte.AVIAO, "DT-ANG", "TAAG", 120);
        sistema.getTransportes().registar(
                TipoTransporte.MINIBUS, "LD-19-88", "SGO Transportes", 18);

        // Viagens
        sistema.getViagens().registar(
                "Luanda", "Benguela", "2026-12-01 07:30", 8500.0, "TRP001");
        sistema.getViagens().registar(
                "Luanda", "Lubango", "2026-12-02 09:00", 45000.0, "TRP002");
        sistema.getViagens().registar(
                "Luanda", "Sumbe", "2026-12-03 14:00", 6000.0, "TRP003");

        // Reserva + bilhete de exemplo
        sistema.getReservas().registar("PAS001", "VIG001", "2026-11-18", 1);
        sistema.getBilhetes().emitir("RES001", "2026-11-18", "14B");
    }
}
