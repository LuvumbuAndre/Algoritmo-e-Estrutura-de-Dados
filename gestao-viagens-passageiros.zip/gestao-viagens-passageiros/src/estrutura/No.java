package estrutura;

/**
 * Nó de lista encadeada usado na resolução de colisões
 * por encadeamento (separate chaining).
 */
public class No<K, V> {
    private K chave;
    private V valor;
    private No<K, V> proximo;

    public No(K chave, V valor) {
        this.chave = chave;
        this.valor = valor;
        this.proximo = null;
    }

    public K getChave() {
        return chave;
    }

    public V getValor() {
        return valor;
    }

    public void setValor(V valor) {
        this.valor = valor;
    }

    public No<K, V> getProximo() {
        return proximo;
    }

    public void setProximo(No<K, V> proximo) {
        this.proximo = proximo;
    }
}
