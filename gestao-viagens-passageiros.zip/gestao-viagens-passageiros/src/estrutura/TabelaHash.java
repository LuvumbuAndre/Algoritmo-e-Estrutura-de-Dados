package estrutura;

/**
 * Tabela de espalhamento (Hash Table) com resolução de colisões
 * por encadeamento (Separate Chaining).
 *
 * Função hash: método da divisão — h(k) = k mod m
 * Chaves string: polinómio rolling hash antes do módulo.
 *
 * Implementação própria para o seminário de AED I — NÃO usa java.util.HashMap.
 *
 * @param <K> tipo da chave
 * @param <V> tipo do valor
 */
public class TabelaHash<K, V> {

    private static final int CAPACIDADE_PADRAO = 11; // primo: melhora distribuição
    private static final double FACTOR_CARGA_MAX = 0.75;

    private No<K, V>[] baldes;
    private int capacidade;
    private int tamanho;

    @SuppressWarnings("unchecked")
    public TabelaHash() {
        this.capacidade = CAPACIDADE_PADRAO;
        this.baldes = (No<K, V>[]) new No[capacidade];
        this.tamanho = 0;
    }

    @SuppressWarnings("unchecked")
    public TabelaHash(int capacidadeInicial) {
        if (capacidadeInicial < 1) {
            throw new IllegalArgumentException("Capacidade deve ser >= 1");
        }
        this.capacidade = capacidadeInicial;
        this.baldes = (No<K, V>[]) new No[capacidade];
        this.tamanho = 0;
    }

    /**
     * Converte a chave num índice [0 .. capacidade-1].
     * Strings: soma ponderada de caracteres (base 31) + método da divisão.
     */
    public int hash(K chave) {
        if (chave == null) {
            throw new IllegalArgumentException("Chave não pode ser nula");
        }
        int codigo;
        if (chave instanceof String) {
            codigo = hashString((String) chave);
        } else {
            codigo = chave.hashCode();
        }
        // Garante índice não negativo (Java % pode ser negativo)
        return Math.floorMod(codigo, capacidade);
    }

    /**
     * Hash polinomial para cadeias: ((c0*31 + c1)*31 + ... ) mod 2^32
     */
    private int hashString(String s) {
        int h = 0;
        for (int i = 0; i < s.length(); i++) {
            h = 31 * h + s.charAt(i);
        }
        return h;
    }

    /**
     * Insere ou actualiza o valor associado à chave.
     * Em caso de colisão, o novo nó é ligado no início da lista do balde.
     */
    public void inserir(K chave, V valor) {
        if (factorCarga() >= FACTOR_CARGA_MAX) {
            rehash();
        }
        int indice = hash(chave);
        No<K, V> actual = baldes[indice];

        while (actual != null) {
            if (actual.getChave().equals(chave)) {
                actual.setValor(valor); // actualização
                return;
            }
            actual = actual.getProximo();
        }

        // Colisão ou balde vazio: encadeamento à cabeça
        No<K, V> novo = new No<>(chave, valor);
        novo.setProximo(baldes[indice]);
        baldes[indice] = novo;
        tamanho++;
    }

    /**
     * Pesquisa o valor pela chave. Retorna null se não existir.
     */
    public V pesquisar(K chave) {
        int indice = hash(chave);
        No<K, V> actual = baldes[indice];
        while (actual != null) {
            if (actual.getChave().equals(chave)) {
                return actual.getValor();
            }
            actual = actual.getProximo();
        }
        return null;
    }

    /**
     * Indica se a chave existe na tabela.
     */
    public boolean contem(K chave) {
        return pesquisar(chave) != null;
    }

    /**
     * Remove o par chave-valor. Retorna true se removeu.
     */
    public boolean remover(K chave) {
        int indice = hash(chave);
        No<K, V> actual = baldes[indice];
        No<K, V> anterior = null;

        while (actual != null) {
            if (actual.getChave().equals(chave)) {
                if (anterior == null) {
                    baldes[indice] = actual.getProximo();
                } else {
                    anterior.setProximo(actual.getProximo());
                }
                tamanho--;
                return true;
            }
            anterior = actual;
            actual = actual.getProximo();
        }
        return false;
    }

    public int tamanho() {
        return tamanho;
    }

    public boolean vazia() {
        return tamanho == 0;
    }

    public int getCapacidade() {
        return capacidade;
    }

    /**
     * Factor de carga α = n / m
     */
    public double factorCarga() {
        return (double) tamanho / capacidade;
    }

    /**
     * Número de elementos no balde (útil para demonstrar colisões).
     */
    public int tamanhoBalde(int indice) {
        if (indice < 0 || indice >= capacidade) {
            return 0;
        }
        int contador = 0;
        No<K, V> actual = baldes[indice];
        while (actual != null) {
            contador++;
            actual = actual.getProximo();
        }
        return contador;
    }

    /**
     * Indica se o balde tem colisão (mais de um elemento).
     */
    public boolean temColisao(int indice) {
        return tamanhoBalde(indice) > 1;
    }

    /**
     * Conta quantos baldes têm pelo menos uma colisão.
     */
    public int contarBaldesComColisao() {
        int total = 0;
        for (int i = 0; i < capacidade; i++) {
            if (temColisao(i)) {
                total++;
            }
        }
        return total;
    }

    /**
     * Devolve todas as chaves (ordem dos baldes) como Object[].
     */
    public Object[] chaves() {
        Object[] resultado = new Object[tamanho];
        int pos = 0;
        for (int i = 0; i < capacidade; i++) {
            No<K, V> actual = baldes[i];
            while (actual != null) {
                resultado[pos++] = actual.getChave();
                actual = actual.getProximo();
            }
        }
        return resultado;
    }

    /**
     * Devolve todos os valores como Object[].
     */
    public Object[] valores() {
        Object[] resultado = new Object[tamanho];
        int pos = 0;
        for (int i = 0; i < capacidade; i++) {
            No<K, V> actual = baldes[i];
            while (actual != null) {
                resultado[pos++] = actual.getValor();
                actual = actual.getProximo();
            }
        }
        return resultado;
    }

    /**
     * Duplica a capacidade (próximo ímpar) e reinsere todos os elementos.
     */
    @SuppressWarnings("unchecked")
    private void rehash() {
        No<K, V>[] antigos = baldes;
        int capacidadeAntiga = capacidade;
        capacidade = capacidade * 2 + 1; // tende a ímpar
        baldes = (No<K, V>[]) new No[capacidade];
        tamanho = 0;

        for (int i = 0; i < capacidadeAntiga; i++) {
            No<K, V> actual = antigos[i];
            while (actual != null) {
                inserir(actual.getChave(), actual.getValor());
                actual = actual.getProximo();
            }
        }
    }

    /**
     * Representação textual dos baldes — ideal para demonstração no seminário.
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format(
                "TabelaHash { n=%d, m=%d, α=%.3f, colisões=%d }%n",
                tamanho, capacidade, factorCarga(), contarBaldesComColisao()));

        for (int i = 0; i < capacidade; i++) {
            sb.append(String.format("[%2d]", i));
            No<K, V> actual = baldes[i];
            if (actual == null) {
                sb.append(" → ∅");
            } else {
                while (actual != null) {
                    sb.append(" → (").append(actual.getChave()).append(")");
                    actual = actual.getProximo();
                }
                if (temColisao(i)) {
                    sb.append("  << COLISÃO");
                }
            }
            sb.append(System.lineSeparator());
        }
        return sb.toString();
    }
}
