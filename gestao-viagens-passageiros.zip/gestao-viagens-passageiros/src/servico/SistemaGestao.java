package servico;

/**
 * Fachada que agrega todos os serviços do sistema.
 */
public class SistemaGestao {

    private final ServicoPassageiros passageiros;
    private final ServicoTransportes transportes;
    private final ServicoViagens viagens;
    private final ServicoReservas reservas;
    private final ServicoBilhetes bilhetes;

    public SistemaGestao() {
        this.passageiros = new ServicoPassageiros();
        this.transportes = new ServicoTransportes();
        this.viagens = new ServicoViagens(transportes);
        this.reservas = new ServicoReservas(passageiros, viagens);
        this.bilhetes = new ServicoBilhetes(reservas, viagens);
    }

    public ServicoPassageiros getPassageiros() {
        return passageiros;
    }

    public ServicoTransportes getTransportes() {
        return transportes;
    }

    public ServicoViagens getViagens() {
        return viagens;
    }

    public ServicoReservas getReservas() {
        return reservas;
    }

    public ServicoBilhetes getBilhetes() {
        return bilhetes;
    }
}
