package servico;

/**
 * Gera códigos únicos sequenciais por prefixo (PAS001, VIG001, ...).
 */
public class GeradorCodigo {
    private int contador;

    public GeradorCodigo() {
        this.contador = 0;
    }

    public GeradorCodigo(int inicio) {
        this.contador = inicio;
    }

    public synchronized String proximo(String prefixo) {
        contador++;
        return String.format("%s%03d", prefixo, contador);
    }

    public void sincronizarCom(int valorMinimo) {
        if (valorMinimo > contador) {
            contador = valorMinimo;
        }
    }
}
