package servico;

import estrutura.TabelaHash;
import modelo.TipoTransporte;
import modelo.Transporte;

public class ServicoTransportes {

    private final TabelaHash<String, Transporte> porCodigo;
    private final GeradorCodigo gerador;

    public ServicoTransportes() {
        this.porCodigo = new TabelaHash<>();
        this.gerador = new GeradorCodigo();
    }

    public Transporte registar(TipoTransporte tipo, String identificacao,
                               String empresa, int capacidade) {
        if (tipo == null) {
            throw new IllegalArgumentException("Tipo de transporte é obrigatório.");
        }
        if (identificacao == null || identificacao.isBlank()) {
            throw new IllegalArgumentException("Identificação (matrícula/prefixo) é obrigatória.");
        }
        if (capacidade <= 0) {
            throw new IllegalArgumentException("Capacidade deve ser positiva.");
        }

        String codigo = gerador.proximo("TRP");
        Transporte t = new Transporte(
                codigo, tipo, identificacao.trim().toUpperCase(),
                empresa == null ? "" : empresa.trim(), capacidade
        );
        porCodigo.inserir(codigo, t);
        return t;
    }

    public Transporte pesquisar(String codigo) {
        if (codigo == null) {
            return null;
        }
        return porCodigo.pesquisar(codigo.trim().toUpperCase());
    }

    public boolean remover(String codigo) {
        return porCodigo.remover(codigo == null ? "" : codigo.trim().toUpperCase());
    }

    public Transporte[] listarTodos() {
        Object[] valores = porCodigo.valores();
        Transporte[] lista = new Transporte[valores.length];
        for (int i = 0; i < valores.length; i++) {
            lista[i] = (Transporte) valores[i];
        }
        return lista;
    }

    public int total() {
        return porCodigo.tamanho();
    }

    public TabelaHash<String, Transporte> getTabela() {
        return porCodigo;
    }
}
