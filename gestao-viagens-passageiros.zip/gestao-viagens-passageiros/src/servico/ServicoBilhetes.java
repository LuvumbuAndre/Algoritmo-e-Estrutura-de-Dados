package servico;

import estrutura.TabelaHash;
import modelo.Bilhete;
import modelo.EstadoBilhete;
import modelo.EstadoReserva;
import modelo.Reserva;
import modelo.Viagem;

public class ServicoBilhetes {

    private final TabelaHash<String, Bilhete> porNumero;
    private final GeradorCodigo gerador;
    private final ServicoReservas servicoReservas;
    private final ServicoViagens servicoViagens;

    public ServicoBilhetes(ServicoReservas servicoReservas, ServicoViagens servicoViagens) {
        this.porNumero = new TabelaHash<>();
        this.gerador = new GeradorCodigo();
        this.servicoReservas = servicoReservas;
        this.servicoViagens = servicoViagens;
    }

    public Bilhete emitir(String codigoReserva, String dataEmissao, String assento) {
        Reserva r = servicoReservas.pesquisar(codigoReserva);
        if (r == null) {
            throw new IllegalArgumentException("Reserva não encontrada: " + codigoReserva);
        }
        if (r.getEstado() != EstadoReserva.CONFIRMADA) {
            throw new IllegalArgumentException(
                    "Só é possível emitir bilhete para reservas confirmadas. Estado: " + r.getEstado());
        }

        Viagem v = servicoViagens.pesquisar(r.getCodigoViagem());
        double valor = v == null ? 0.0 : v.getPreco() * r.getQuantidadeLugares();

        String numero = gerador.proximo("BIL");
        Bilhete b = new Bilhete(
                numero,
                r.getCodigo(),
                dataEmissao,
                assento == null || assento.isBlank() ? "A1" : assento.trim().toUpperCase(),
                EstadoBilhete.EMITIDO,
                valor
        );
        porNumero.inserir(numero, b);
        r.setEstado(EstadoReserva.UTILIZADA);
        return b;
    }

    public Bilhete pesquisar(String numero) {
        if (numero == null) {
            return null;
        }
        return porNumero.pesquisar(numero.trim().toUpperCase());
    }

    public boolean cancelar(String numero) {
        Bilhete b = pesquisar(numero);
        if (b == null || b.getEstado() == EstadoBilhete.CANCELADO) {
            return false;
        }
        b.setEstado(EstadoBilhete.CANCELADO);
        return true;
    }

    public boolean remover(String numero) {
        return porNumero.remover(numero == null ? "" : numero.trim().toUpperCase());
    }

    public Bilhete[] listarTodos() {
        Object[] valores = porNumero.valores();
        Bilhete[] lista = new Bilhete[valores.length];
        for (int i = 0; i < valores.length; i++) {
            lista[i] = (Bilhete) valores[i];
        }
        return lista;
    }

    public int total() {
        return porNumero.tamanho();
    }

    public TabelaHash<String, Bilhete> getTabela() {
        return porNumero;
    }
}
