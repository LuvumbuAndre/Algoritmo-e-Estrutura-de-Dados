package servico;

import estrutura.TabelaHash;
import modelo.Transporte;
import modelo.Viagem;

public class ServicoViagens {

    private final TabelaHash<String, Viagem> porCodigo;
    private final GeradorCodigo gerador;
    private final ServicoTransportes servicoTransportes;

    public ServicoViagens(ServicoTransportes servicoTransportes) {
        this.porCodigo = new TabelaHash<>();
        this.gerador = new GeradorCodigo();
        this.servicoTransportes = servicoTransportes;
    }

    public Viagem registar(String origem, String destino, String dataHoraPartida,
                           double preco, String codigoTransporte) {
        if (origem == null || origem.isBlank() || destino == null || destino.isBlank()) {
            throw new IllegalArgumentException("Origem e destino são obrigatórios.");
        }
        Transporte tr = servicoTransportes.pesquisar(codigoTransporte);
        if (tr == null) {
            throw new IllegalArgumentException("Transporte não encontrado: " + codigoTransporte);
        }
        if (preco < 0) {
            throw new IllegalArgumentException("Preço não pode ser negativo.");
        }

        String codigo = gerador.proximo("VIG");
        Viagem v = new Viagem(
                codigo,
                origem.trim(),
                destino.trim(),
                dataHoraPartida,
                preco,
                tr.getCapacidade(),
                tr.getCodigo()
        );
        porCodigo.inserir(codigo, v);
        return v;
    }

    public Viagem pesquisar(String codigo) {
        if (codigo == null) {
            return null;
        }
        return porCodigo.pesquisar(codigo.trim().toUpperCase());
    }

    public boolean remover(String codigo) {
        return porCodigo.remover(codigo == null ? "" : codigo.trim().toUpperCase());
    }

    public Viagem[] listarTodos() {
        Object[] valores = porCodigo.valores();
        Viagem[] lista = new Viagem[valores.length];
        for (int i = 0; i < valores.length; i++) {
            lista[i] = (Viagem) valores[i];
        }
        return lista;
    }

    public int total() {
        return porCodigo.tamanho();
    }

    public TabelaHash<String, Viagem> getTabela() {
        return porCodigo;
    }
}
