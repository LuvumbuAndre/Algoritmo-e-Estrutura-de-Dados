package servico;

import estrutura.TabelaHash;
import modelo.Passageiro;
import modelo.Sexo;

/**
 * Gestão de passageiros — armazenamento em TabelaHash (chave = código).
 * Índice auxiliar por BI para pesquisa rápida.
 */
public class ServicoPassageiros {

    private final TabelaHash<String, Passageiro> porCodigo;
    private final TabelaHash<String, String> biParaCodigo; // BI → código
    private final GeradorCodigo gerador;

    public ServicoPassageiros() {
        this.porCodigo = new TabelaHash<>();
        this.biParaCodigo = new TabelaHash<>();
        this.gerador = new GeradorCodigo();
    }

    public Passageiro registar(String nomeCompleto, String numeroBI,
                               String dataNascimento, Sexo sexo,
                               String telefone, String email) {
        if (nomeCompleto == null || nomeCompleto.isBlank()) {
            throw new IllegalArgumentException("Nome completo é obrigatório.");
        }
        if (numeroBI == null || numeroBI.isBlank()) {
            throw new IllegalArgumentException("Número do BI é obrigatório.");
        }
        if (biParaCodigo.contem(numeroBI.trim().toUpperCase())) {
            throw new IllegalArgumentException("Já existe passageiro com este BI.");
        }
        if (sexo == null) {
            throw new IllegalArgumentException("Sexo é obrigatório.");
        }

        String codigo = gerador.proximo("PAS");
        Passageiro p = new Passageiro(
                codigo,
                nomeCompleto.trim(),
                numeroBI.trim().toUpperCase(),
                dataNascimento,
                sexo,
                telefone == null ? "" : telefone.trim(),
                email == null ? "" : email.trim()
        );
        porCodigo.inserir(codigo, p);
        biParaCodigo.inserir(p.getNumeroBI(), codigo);
        return p;
    }

    public Passageiro pesquisarPorCodigo(String codigo) {
        if (codigo == null) {
            return null;
        }
        return porCodigo.pesquisar(codigo.trim().toUpperCase());
    }

    public Passageiro pesquisarPorBI(String bi) {
        if (bi == null) {
            return null;
        }
        String codigo = biParaCodigo.pesquisar(bi.trim().toUpperCase());
        if (codigo == null) {
            return null;
        }
        return porCodigo.pesquisar(codigo);
    }

    public boolean remover(String codigo) {
        Passageiro p = pesquisarPorCodigo(codigo);
        if (p == null) {
            return false;
        }
        biParaCodigo.remover(p.getNumeroBI());
        return porCodigo.remover(p.getCodigo());
    }

    public Passageiro[] listarTodos() {
        Object[] valores = porCodigo.valores();
        Passageiro[] lista = new Passageiro[valores.length];
        for (int i = 0; i < valores.length; i++) {
            lista[i] = (Passageiro) valores[i];
        }
        return lista;
    }

    public int total() {
        return porCodigo.tamanho();
    }

    public TabelaHash<String, Passageiro> getTabela() {
        return porCodigo;
    }
}
