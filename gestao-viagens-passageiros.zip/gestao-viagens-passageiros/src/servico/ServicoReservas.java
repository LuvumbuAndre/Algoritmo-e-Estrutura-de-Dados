package servico;

import estrutura.TabelaHash;
import modelo.EstadoReserva;
import modelo.Passageiro;
import modelo.Reserva;
import modelo.Viagem;

public class ServicoReservas {

    private final TabelaHash<String, Reserva> porCodigo;
    private final GeradorCodigo gerador;
    private final ServicoPassageiros servicoPassageiros;
    private final ServicoViagens servicoViagens;

    public ServicoReservas(ServicoPassageiros servicoPassageiros, ServicoViagens servicoViagens) {
        this.porCodigo = new TabelaHash<>();
        this.gerador = new GeradorCodigo();
        this.servicoPassageiros = servicoPassageiros;
        this.servicoViagens = servicoViagens;
    }

    public Reserva registar(String codigoPassageiro, String codigoViagem,
                            String dataReserva, int quantidadeLugares) {
        Passageiro p = servicoPassageiros.pesquisarPorCodigo(codigoPassageiro);
        if (p == null) {
            throw new IllegalArgumentException("Passageiro não encontrado: " + codigoPassageiro);
        }
        Viagem v = servicoViagens.pesquisar(codigoViagem);
        if (v == null) {
            throw new IllegalArgumentException("Viagem não encontrada: " + codigoViagem);
        }
        if (quantidadeLugares <= 0) {
            throw new IllegalArgumentException("Quantidade de lugares deve ser positiva.");
        }
        if (v.getLugaresDisponiveis() < quantidadeLugares) {
            throw new IllegalArgumentException(
                    "Lugares insuficientes. Disponíveis: " + v.getLugaresDisponiveis());
        }

        for (int i = 0; i < quantidadeLugares; i++) {
            v.reservarLugar();
        }

        String codigo = gerador.proximo("RES");
        Reserva r = new Reserva(
                codigo,
                p.getCodigo(),
                v.getCodigo(),
                dataReserva,
                EstadoReserva.CONFIRMADA,
                quantidadeLugares
        );
        porCodigo.inserir(codigo, r);
        return r;
    }

    public Reserva pesquisar(String codigo) {
        if (codigo == null) {
            return null;
        }
        return porCodigo.pesquisar(codigo.trim().toUpperCase());
    }

    public boolean cancelar(String codigo) {
        Reserva r = pesquisar(codigo);
        if (r == null) {
            return false;
        }
        if (r.getEstado() == EstadoReserva.CANCELADA) {
            return false;
        }
        Viagem v = servicoViagens.pesquisar(r.getCodigoViagem());
        if (v != null) {
            for (int i = 0; i < r.getQuantidadeLugares(); i++) {
                v.libertarLugar();
            }
        }
        r.setEstado(EstadoReserva.CANCELADA);
        return true;
    }

    public boolean remover(String codigo) {
        Reserva r = pesquisar(codigo);
        if (r == null) {
            return false;
        }
        if (r.getEstado() != EstadoReserva.CANCELADA) {
            cancelar(codigo);
        }
        return porCodigo.remover(r.getCodigo());
    }

    public Reserva[] listarTodos() {
        Object[] valores = porCodigo.valores();
        Reserva[] lista = new Reserva[valores.length];
        for (int i = 0; i < valores.length; i++) {
            lista[i] = (Reserva) valores[i];
        }
        return lista;
    }

    public int total() {
        return porCodigo.tamanho();
    }

    public TabelaHash<String, Reserva> getTabela() {
        return porCodigo;
    }
}
