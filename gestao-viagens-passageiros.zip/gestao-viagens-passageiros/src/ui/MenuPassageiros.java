package ui;

import modelo.Passageiro;
import modelo.Sexo;
import servico.ServicoPassageiros;

public class MenuPassageiros {

    private final Consola consola;
    private final ServicoPassageiros servico;

    public MenuPassageiros(Consola consola, ServicoPassageiros servico) {
        this.consola = consola;
        this.servico = servico;
    }

    public void executar() {
        boolean voltar = false;
        while (!voltar) {
            consola.titulo("MÓDULO 1 — Gestão de Passageiros");
            System.out.println("  1. Registar novo passageiro");
            System.out.println("  2. Pesquisar por código");
            System.out.println("  3. Pesquisar por BI");
            System.out.println("  4. Listar todos");
            System.out.println("  5. Remover passageiro");
            System.out.println("  6. Ver tabela hash (estrutura)");
            System.out.println("  0. Voltar");
            consola.separador();
            int op = consola.lerInteiro("Opção");

            switch (op) {
                case 1 -> registar();
                case 2 -> pesquisarCodigo();
                case 3 -> pesquisarBI();
                case 4 -> listar();
                case 5 -> remover();
                case 6 -> mostrarTabela();
                case 0 -> voltar = true;
                default -> consola.erro("Opção inválida.");
            }
        }
    }

    private void registar() {
        consola.titulo("Registar Passageiro");
        String nome = consola.lerTexto("Nome completo");
        String bi = consola.lerTexto("Número do BI");
        String nasc = consola.lerTexto("Data de nascimento (AAAA-MM-DD)");
        System.out.println("Sexo: M = Masculino | F = Feminino");
        Sexo sexo = Sexo.deCodigo(consola.lerTexto("Sexo"));
        String tel = consola.lerTexto("Telefone");
        String email = consola.lerTexto("Email");
        try {
            Passageiro p = servico.registar(nome, bi, nasc, sexo, tel, email);
            consola.sucesso("Passageiro registado: " + p.getCodigo());
            System.out.println(p);
        } catch (IllegalArgumentException e) {
            consola.erro(e.getMessage());
        }
        consola.pausar();
    }

    private void pesquisarCodigo() {
        String codigo = consola.lerTexto("Código (ex.: PAS001)");
        Passageiro p = servico.pesquisarPorCodigo(codigo);
        if (p == null) {
            consola.erro("Passageiro não encontrado.");
        } else {
            System.out.println(p);
        }
        consola.pausar();
    }

    private void pesquisarBI() {
        String bi = consola.lerTexto("Número do BI");
        Passageiro p = servico.pesquisarPorBI(bi);
        if (p == null) {
            consola.erro("Passageiro não encontrado.");
        } else {
            System.out.println(p);
        }
        consola.pausar();
    }

    private void listar() {
        Passageiro[] lista = servico.listarTodos();
        if (lista.length == 0) {
            consola.mensagem("Nenhum passageiro registado.");
        } else {
            consola.mensagem("Total: " + lista.length);
            for (Passageiro p : lista) {
                System.out.println("  • " + p);
            }
        }
        consola.pausar();
    }

    private void remover() {
        String codigo = consola.lerTexto("Código a remover");
        if (servico.remover(codigo)) {
            consola.sucesso("Passageiro removido.");
        } else {
            consola.erro("Não foi possível remover (código inexistente).");
        }
        consola.pausar();
    }

    private void mostrarTabela() {
        consola.titulo("Tabela Hash de Passageiros (por código)");
        System.out.println(servico.getTabela());
        consola.pausar();
    }
}
