package ui;

import modelo.Bilhete;
import servico.ServicoBilhetes;

public class MenuBilhetes {

    private final Consola consola;
    private final ServicoBilhetes servico;

    public MenuBilhetes(Consola consola, ServicoBilhetes servico) {
        this.consola = consola;
        this.servico = servico;
    }

    public void executar() {
        boolean voltar = false;
        while (!voltar) {
            consola.titulo("MÓDULO 5 — Gestão de Bilhetes");
            System.out.println("  1. Emitir bilhete");
            System.out.println("  2. Pesquisar por número");
            System.out.println("  3. Listar todos");
            System.out.println("  4. Cancelar bilhete");
            System.out.println("  5. Remover bilhete");
            System.out.println("  6. Ver tabela hash");
            System.out.println("  0. Voltar");
            consola.separador();
            int op = consola.lerInteiro("Opção");

            switch (op) {
                case 1 -> emitir();
                case 2 -> pesquisar();
                case 3 -> listar();
                case 4 -> cancelar();
                case 5 -> remover();
                case 6 -> {
                    System.out.println(servico.getTabela());
                    consola.pausar();
                }
                case 0 -> voltar = true;
                default -> consola.erro("Opção inválida.");
            }
        }
    }

    private void emitir() {
        consola.titulo("Emitir Bilhete");
        String res = consola.lerTexto("Código da reserva (ex.: RES001)");
        String data = consola.lerTexto("Data de emissão (AAAA-MM-DD)");
        String assento = consola.lerTexto("Assento (ex.: 12A)");
        try {
            Bilhete b = servico.emitir(res, data, assento);
            consola.sucesso("Bilhete emitido: " + b.getNumero());
            System.out.println(b);
        } catch (IllegalArgumentException e) {
            consola.erro(e.getMessage());
        }
        consola.pausar();
    }

    private void pesquisar() {
        Bilhete b = servico.pesquisar(consola.lerTexto("Número (ex.: BIL001)"));
        if (b == null) {
            consola.erro("Bilhete não encontrado.");
        } else {
            System.out.println(b);
        }
        consola.pausar();
    }

    private void listar() {
        Bilhete[] lista = servico.listarTodos();
        if (lista.length == 0) {
            consola.mensagem("Nenhum bilhete emitido.");
        } else {
            for (Bilhete b : lista) {
                System.out.println("  • " + b);
            }
        }
        consola.pausar();
    }

    private void cancelar() {
        if (servico.cancelar(consola.lerTexto("Número a cancelar"))) {
            consola.sucesso("Bilhete cancelado.");
        } else {
            consola.erro("Não foi possível cancelar.");
        }
        consola.pausar();
    }

    private void remover() {
        if (servico.remover(consola.lerTexto("Número a remover"))) {
            consola.sucesso("Bilhete removido.");
        } else {
            consola.erro("Não foi possível remover.");
        }
        consola.pausar();
    }
}
