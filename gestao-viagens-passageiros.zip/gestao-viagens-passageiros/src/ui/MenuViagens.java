package ui;

import modelo.Viagem;
import servico.ServicoViagens;

public class MenuViagens {

    private final Consola consola;
    private final ServicoViagens servico;

    public MenuViagens(Consola consola, ServicoViagens servico) {
        this.consola = consola;
        this.servico = servico;
    }

    public void executar() {
        boolean voltar = false;
        while (!voltar) {
            consola.titulo("MÓDULO 3 — Gestão de Viagens");
            System.out.println("  1. Registar viagem");
            System.out.println("  2. Pesquisar por código");
            System.out.println("  3. Listar todas");
            System.out.println("  4. Remover viagem");
            System.out.println("  5. Ver tabela hash");
            System.out.println("  0. Voltar");
            consola.separador();
            int op = consola.lerInteiro("Opção");

            switch (op) {
                case 1 -> registar();
                case 2 -> pesquisar();
                case 3 -> listar();
                case 4 -> remover();
                case 5 -> {
                    System.out.println(servico.getTabela());
                    consola.pausar();
                }
                case 0 -> voltar = true;
                default -> consola.erro("Opção inválida.");
            }
        }
    }

    private void registar() {
        consola.titulo("Registar Viagem");
        String origem = consola.lerTexto("Origem (ex.: Luanda)");
        String destino = consola.lerTexto("Destino (ex.: Benguela)");
        String dataHora = consola.lerTexto("Data/hora partida (AAAA-MM-DD HH:MM)");
        double preco = consola.lerDecimal("Preço (Kz)");
        String codigoTr = consola.lerTexto("Código do transporte (ex.: TRP001)");
        try {
            Viagem v = servico.registar(origem, destino, dataHora, preco, codigoTr);
            consola.sucesso("Viagem registada: " + v.getCodigo());
            System.out.println(v);
        } catch (IllegalArgumentException e) {
            consola.erro(e.getMessage());
        }
        consola.pausar();
    }

    private void pesquisar() {
        Viagem v = servico.pesquisar(consola.lerTexto("Código (ex.: VIG001)"));
        if (v == null) {
            consola.erro("Viagem não encontrada.");
        } else {
            System.out.println(v);
        }
        consola.pausar();
    }

    private void listar() {
        Viagem[] lista = servico.listarTodos();
        if (lista.length == 0) {
            consola.mensagem("Nenhuma viagem registada.");
        } else {
            for (Viagem v : lista) {
                System.out.println("  • " + v);
            }
        }
        consola.pausar();
    }

    private void remover() {
        if (servico.remover(consola.lerTexto("Código a remover"))) {
            consola.sucesso("Viagem removida.");
        } else {
            consola.erro("Não foi possível remover.");
        }
        consola.pausar();
    }
}
