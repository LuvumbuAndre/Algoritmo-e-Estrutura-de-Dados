package ui;

import demo.DemoColisoes;
import servico.SistemaGestao;

import java.util.Scanner;

public class MenuPrincipal {

    private final Scanner scanner;
    private final Consola consola;
    private final SistemaGestao sistema;

    public MenuPrincipal(SistemaGestao sistema) {
        this.scanner = new Scanner(System.in);
        this.consola = new Consola(scanner);
        this.sistema = sistema;
    }

    public void iniciar() {
        boolean sair = false;
        while (!sair) {
            consola.titulo("Sistema de Gestão de Viagens e Passageiros");
            System.out.println("  Seminário AED I — Tabelas de Espalhamento");
            System.out.println();
            System.out.println("  1. Passageiros");
            System.out.println("  2. Transportes");
            System.out.println("  3. Viagens");
            System.out.println("  4. Reservas");
            System.out.println("  5. Bilhetes");
            System.out.println("  6. Demonstração de colisões (seminário)");
            System.out.println("  7. Resumo do sistema");
            System.out.println("  0. Sair");
            consola.separador();
            int op = consola.lerInteiro("Opção");

            switch (op) {
                case 1 -> new MenuPassageiros(consola, sistema.getPassageiros()).executar();
                case 2 -> new MenuTransportes(consola, sistema.getTransportes()).executar();
                case 3 -> new MenuViagens(consola, sistema.getViagens()).executar();
                case 4 -> new MenuReservas(consola, sistema.getReservas()).executar();
                case 5 -> new MenuBilhetes(consola, sistema.getBilhetes()).executar();
                case 6 -> {
                    DemoColisoes.executar();
                    consola.pausar();
                }
                case 7 -> resumo();
                case 0 -> {
                    consola.mensagem("Até breve!");
                    sair = true;
                }
                default -> consola.erro("Opção inválida.");
            }
        }
    }

    private void resumo() {
        consola.titulo("Resumo do Sistema");
        System.out.printf("  Passageiros : %d%n", sistema.getPassageiros().total());
        System.out.printf("  Transportes : %d%n", sistema.getTransportes().total());
        System.out.printf("  Viagens     : %d%n", sistema.getViagens().total());
        System.out.printf("  Reservas    : %d%n", sistema.getReservas().total());
        System.out.printf("  Bilhetes    : %d%n", sistema.getBilhetes().total());
        System.out.println();
        System.out.println("  Factor de carga (passageiros): "
                + String.format("%.3f", sistema.getPassageiros().getTabela().factorCarga()));
        consola.pausar();
    }
}
