package ui;

import modelo.TipoTransporte;
import modelo.Transporte;
import servico.ServicoTransportes;

public class MenuTransportes {

    private final Consola consola;
    private final ServicoTransportes servico;

    public MenuTransportes(Consola consola, ServicoTransportes servico) {
        this.consola = consola;
        this.servico = servico;
    }

    public void executar() {
        boolean voltar = false;
        while (!voltar) {
            consola.titulo("MÓDULO 2 — Gestão de Transportes");
            System.out.println("  1. Registar transporte");
            System.out.println("  2. Pesquisar por código");
            System.out.println("  3. Listar todos");
            System.out.println("  4. Remover transporte");
            System.out.println("  5. Ver tabela hash");
            System.out.println("  0. Voltar");
            consola.separador();
            int op = consola.lerInteiro("Opção");

            switch (op) {
                case 1 -> registar();
                case 2 -> pesquisar();
                case 3 -> listar();
                case 4 -> remover();
                case 5 -> {
                    System.out.println(servico.getTabela());
                    consola.pausar();
                }
                case 0 -> voltar = true;
                default -> consola.erro("Opção inválida.");
            }
        }
    }

    private void registar() {
        consola.titulo("Registar Transporte");
        System.out.println("Tipos: 1=Autocarro 2=Minibus 3=Avião 4=Comboio 5=Barco");
        TipoTransporte tipo = TipoTransporte.deCodigo(consola.lerTexto("Tipo"));
        String id = consola.lerTexto("Identificação (matrícula/prefixo)");
        String empresa = consola.lerTexto("Empresa");
        int capacidade = consola.lerInteiro("Capacidade (lugares)");
        try {
            Transporte t = servico.registar(tipo, id, empresa, capacidade);
            consola.sucesso("Transporte registado: " + t.getCodigo());
            System.out.println(t);
        } catch (IllegalArgumentException e) {
            consola.erro(e.getMessage());
        }
        consola.pausar();
    }

    private void pesquisar() {
        Transporte t = servico.pesquisar(consola.lerTexto("Código (ex.: TRP001)"));
        if (t == null) {
            consola.erro("Transporte não encontrado.");
        } else {
            System.out.println(t);
        }
        consola.pausar();
    }

    private void listar() {
        Transporte[] lista = servico.listarTodos();
        if (lista.length == 0) {
            consola.mensagem("Nenhum transporte registado.");
        } else {
            for (Transporte t : lista) {
                System.out.println("  • " + t);
            }
        }
        consola.pausar();
    }

    private void remover() {
        if (servico.remover(consola.lerTexto("Código a remover"))) {
            consola.sucesso("Transporte removido.");
        } else {
            consola.erro("Não foi possível remover.");
        }
        consola.pausar();
    }
}
