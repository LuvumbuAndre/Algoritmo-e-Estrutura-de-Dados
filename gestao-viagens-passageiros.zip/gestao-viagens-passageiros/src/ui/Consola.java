package ui;

import java.util.Scanner;

/**
 * Utilitários de entrada/saída para menus de consola.
 */
public class Consola {

    private final Scanner scanner;

    public Consola(Scanner scanner) {
        this.scanner = scanner;
    }

    public void titulo(String texto) {
        System.out.println();
        System.out.println("════════════════════════════════════════════");
        System.out.println("  " + texto);
        System.out.println("════════════════════════════════════════════");
    }

    public void separador() {
        System.out.println("────────────────────────────────────────────");
    }

    public void mensagem(String texto) {
        System.out.println(texto);
    }

    public void sucesso(String texto) {
        System.out.println("[OK] " + texto);
    }

    public void erro(String texto) {
        System.out.println("[ERRO] " + texto);
    }

    public String lerTexto(String rotulo) {
        System.out.print(rotulo + ": ");
        return scanner.nextLine().trim();
    }

    public String lerTextoOpcional(String rotulo, String padrao) {
        System.out.print(rotulo + " [" + padrao + "]: ");
        String valor = scanner.nextLine().trim();
        return valor.isEmpty() ? padrao : valor;
    }

    public int lerInteiro(String rotulo) {
        while (true) {
            System.out.print(rotulo + ": ");
            String linha = scanner.nextLine().trim();
            try {
                return Integer.parseInt(linha);
            } catch (NumberFormatException e) {
                erro("Introduza um número inteiro válido.");
            }
        }
    }

    public double lerDecimal(String rotulo) {
        while (true) {
            System.out.print(rotulo + ": ");
            String linha = scanner.nextLine().trim().replace(',', '.');
            try {
                return Double.parseDouble(linha);
            } catch (NumberFormatException e) {
                erro("Introduza um número válido.");
            }
        }
    }

    public void pausar() {
        System.out.print("\nPrima ENTER para continuar...");
        scanner.nextLine();
    }
}
