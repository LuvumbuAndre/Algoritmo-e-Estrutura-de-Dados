package ui;

import modelo.Reserva;
import servico.ServicoReservas;

public class MenuReservas {

    private final Consola consola;
    private final ServicoReservas servico;

    public MenuReservas(Consola consola, ServicoReservas servico) {
        this.consola = consola;
        this.servico = servico;
    }

    public void executar() {
        boolean voltar = false;
        while (!voltar) {
            consola.titulo("MÓDULO 4 — Gestão de Reservas");
            System.out.println("  1. Registar reserva");
            System.out.println("  2. Pesquisar por código");
            System.out.println("  3. Listar todas");
            System.out.println("  4. Cancelar reserva");
            System.out.println("  5. Remover reserva");
            System.out.println("  6. Ver tabela hash");
            System.out.println("  0. Voltar");
            consola.separador();
            int op = consola.lerInteiro("Opção");

            switch (op) {
                case 1 -> registar();
                case 2 -> pesquisar();
                case 3 -> listar();
                case 4 -> cancelar();
                case 5 -> remover();
                case 6 -> {
                    System.out.println(servico.getTabela());
                    consola.pausar();
                }
                case 0 -> voltar = true;
                default -> consola.erro("Opção inválida.");
            }
        }
    }

    private void registar() {
        consola.titulo("Registar Reserva");
        String pas = consola.lerTexto("Código do passageiro (ex.: PAS001)");
        String vig = consola.lerTexto("Código da viagem (ex.: VIG001)");
        String data = consola.lerTexto("Data da reserva (AAAA-MM-DD)");
        int lugares = consola.lerInteiro("Quantidade de lugares");
        try {
            Reserva r = servico.registar(pas, vig, data, lugares);
            consola.sucesso("Reserva registada: " + r.getCodigo());
            System.out.println(r);
        } catch (IllegalArgumentException e) {
            consola.erro(e.getMessage());
        }
        consola.pausar();
    }

    private void pesquisar() {
        Reserva r = servico.pesquisar(consola.lerTexto("Código (ex.: RES001)"));
        if (r == null) {
            consola.erro("Reserva não encontrada.");
        } else {
            System.out.println(r);
        }
        consola.pausar();
    }

    private void listar() {
        Reserva[] lista = servico.listarTodos();
        if (lista.length == 0) {
            consola.mensagem("Nenhuma reserva registada.");
        } else {
            for (Reserva r : lista) {
                System.out.println("  • " + r);
            }
        }
        consola.pausar();
    }

    private void cancelar() {
        if (servico.cancelar(consola.lerTexto("Código a cancelar"))) {
            consola.sucesso("Reserva cancelada (lugares libertados).");
        } else {
            consola.erro("Não foi possível cancelar.");
        }
        consola.pausar();
    }

    private void remover() {
        if (servico.remover(consola.lerTexto("Código a remover"))) {
            consola.sucesso("Reserva removida.");
        } else {
            consola.erro("Não foi possível remover.");
        }
        consola.pausar();
    }
}
